import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * 用户系统
 */
public class UserService {
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private Customer customer = new Customer();

    public UserService() {
        this.connection = LinkToMySQL.getConnection();
    }

    //注册
    public boolean Register(Customer customer) {
        try{
            statement = connection.createStatement();

            resultSet = statement.executeQuery("select * from 2014302580184_user where accountNumber = "+"'"+customer.getAccountNumber()+"'");
            if(resultSet.next()) {
                System.out.println("该用户名已存在！");
                return false;
            }else {
                statement.executeUpdate("insert into 2014302580184_user values(NULL ,"+"'"+customer.getName()+"'"+","+"'"+customer.getSex()+"'"+"," +
                        "'"+customer.getAccountNumber()+"'"+","+"'"+customer.getPassword()+"'"+","+"'"+customer.getEmail()+"'"+")");
                System.out.println("注册成功！");
                return true;
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }
    }

    //登陆
    public int Login(String accountnumber,String password){
        try{
            statement = connection.createStatement();

            resultSet = statement.executeQuery("select * from 2014302580184_user where accountNumber ="+"'"+accountnumber+"'");
            if(resultSet.next() == false) {
                System.out.println("用户名不存在！");
                return 0;
            }else if(!resultSet.getString(5).equals(password)){
                System.out.println("密码错误！");
                return 1;
            }else{
                System.out.println("登陆成功！");
                return 2;
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            return 3;
        }
    }

    //退出
    public boolean Logout(int id) {
        customer = null;
        return true;
    }
}
