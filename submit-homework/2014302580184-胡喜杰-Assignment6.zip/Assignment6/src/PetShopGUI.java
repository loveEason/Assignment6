import javax.swing.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 宠物商店GUI
 */
public class PetShopGUI {
    public PetShopGUI() {
        new LoginPage();
    }
}

//登陆界面
class LoginPage {
    private JFrame jFrame;
    private JLabel jLabel;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JTextField jTextField;
    private JPasswordField jPasswordField;
    private JButton jButton;
    private JButton jButton2;
    private UserService userService = new UserService();
    private Customer customer;
    private Customer_MySQL_TABLE customer_mySQL_table;

    public LoginPage(){
        setjFrame();
        setjLabel();
        setjLabel2();
        setjLabel3();
        setjLabel4();
        setjLabel5();
        setjButton();
        setjButton2();
        keyPressed();
    }

    //构造登陆窗口
    private void setjFrame() {
        jFrame = new JFrame("PetShop_Login");
        jFrame.setLayout(null);
        jFrame.setBounds(400,100,450,500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置标签1
    private void setjLabel(){
        jLabel = new JLabel("For you:");
        jLabel.setBounds(50,30,100,20);
        jFrame.add(jLabel);
    }

    //设置标签2
    private void setjLabel2(){
        jLabel2 = new JLabel("Best survice!");
        jLabel2.setBounds(50,70,100,20);
        jFrame.add(jLabel2);
    }

    //设置标签3
    private void setjLabel3() {
        jLabel3 = new JLabel("Lowest price!");
        jLabel3.setBounds(50,110,100,20);
        jFrame.add(jLabel3);
    }

    //设置标签4
    private void setjLabel4(){
        jLabel4 = new JLabel("Account:");
        jLabel4.setBounds(50,200,100,20);
        jFrame.add(jLabel4);
        jTextField = new JTextField();
        jTextField.setBounds(150,200,200,20);
        jFrame.add(jTextField);
    }

    //设置标签5
    private void setjLabel5() {
        jLabel5 = new JLabel("Password:");
        jLabel5.setBounds(50,240,100,20);
        jFrame.add(jLabel5);
        jPasswordField = new JPasswordField();
        jPasswordField.setBounds(150,240,200,20);
        jFrame.add(jPasswordField);
    }

    //设置注册按钮
    private void setjButton() {
        jButton = new JButton("register");
        jButton.setBounds(100,300,80,20);
        jFrame.add(jButton);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                new RegisterPage();
            }
        });
    }

    //设置登陆按钮
    private void setjButton2() {
        jButton2 = new JButton("login");
        jButton2.setBounds(250,300,80,20);
        jFrame.add(jButton2);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String account = jTextField.getText();
                String password = new String(jPasswordField.getPassword());
                int judge = userService.Login(account,password);
                switch (judge){
                    case 0:
                        JOptionPane.showMessageDialog(jFrame,"Not existing Account!");
                        jTextField.setText("");
                        jPasswordField.setText("");
                        break;
                    case 1:
                        JOptionPane.showMessageDialog(jFrame,"Wrong Password!");
                        jTextField.setText("");
                        jPasswordField.setText("");
                        break;
                    case 2:
                        customer_mySQL_table = new Customer_MySQL_TABLE();
                        customer = customer_mySQL_table.getCustomer(account);
                        jFrame.dispose();
                        MainPage mainPage = new MainPage(customer);
                        JOptionPane.showMessageDialog(mainPage.getjFrame(),"Succeed to login!");
                        break;
                }
            }
        });
    }

    //定义按下回车实现的功能
    private void keyPressed() {
        jPasswordField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                int target = e.getKeyCode();
                if(target == KeyEvent.VK_ENTER){
                    String account = jTextField.getText();
                    String password = new String(jPasswordField.getPassword());
                    int judge = userService.Login(account,password);
                    switch (judge){
                        case 0:
                            JOptionPane.showMessageDialog(jFrame,"Not existing Account!");
                            jTextField.setText("");
                            jPasswordField.setText("");
                            break;
                        case 1:
                            JOptionPane.showMessageDialog(jFrame,"Wrong Password!");
                            jTextField.setText("");
                            jPasswordField.setText("");
                            break;
                        case 2:
                            customer_mySQL_table = new Customer_MySQL_TABLE();
                            customer = customer_mySQL_table.getCustomer(account);
                            jFrame.dispose();
                            MainPage mainPage = new MainPage(customer);
                            JOptionPane.showMessageDialog(mainPage.getjFrame(),"Succeed to login!");
                            break;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }

    //得到JFrame
    public JFrame getjFrame(){
        return jFrame;
    }
}

//注册页面
class RegisterPage {
    private JFrame jFrame;
    private JLabel jLabel;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JTextField jTextField;
    private JTextField jTextField2;
    private JPasswordField jPasswordField;
    private JPasswordField jPasswordField2;
    private JButton jButton;
    private JButton jButton2;
    private UserService userService;
    private Customer customer;

    public RegisterPage() {
        setjFrame();
        setjLabel();
        setjLabel2();
        setjLabel3();
        setjLabel4();
        setjButton();
        setjButton2();
        keyPressed();
    }

    //构造注册窗口
    private void setjFrame() {
        jFrame = new JFrame("Register");
        jFrame.setLayout(null);
        jFrame.setBounds(400, 100, 450, 500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置标签1
    private void setjLabel() {
        jLabel = new JLabel("Name:");
        jLabel.setBounds(50,80,100,20);
        jFrame.add(jLabel);
        jTextField = new JTextField();
        jTextField.setBounds(200,80,200,20);
        jFrame.add(jTextField);
    }

    //设置标签2
    private void setjLabel2() {
        jLabel2 = new JLabel("Account:");
        jLabel2.setBounds(50,130,100,20);
        jFrame.add(jLabel2);
        jTextField2 = new JTextField();
        jTextField2.setBounds(200,130,200,20);
        jFrame.add(jTextField2);
    }

    //设置标签3
    private void setjLabel3() {
        jLabel3 = new JLabel("Password:");
        jLabel3.setBounds(50,180,100,20);
        jFrame.add(jLabel3);
        jPasswordField = new JPasswordField();
        jPasswordField.setBounds(200,180,200,20);
        jFrame.add(jPasswordField);
    }

    //设置标签4
    private void setjLabel4() {
        jLabel4 = new JLabel("Password again:");
        jLabel4.setBounds(50,230,100,20);
        jFrame.add(jLabel4);
        jPasswordField2 = new JPasswordField();
        jPasswordField2.setBounds(200, 230, 200, 20);
        jFrame.add(jPasswordField2);
    }

    //设置返回按钮
    private void setjButton() {
        jButton = new JButton("<——Back");
        jButton.setBounds(100,300,100,20);
        jFrame.add(jButton);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                new LoginPage();
            }
        });
    }

    //设置注册按钮
    private void setjButton2() {
        jButton2 = new JButton("register");
        jButton2.setBounds(250,300,100,20);
        jFrame.add(jButton2);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = jTextField.getText();
                String account = jTextField2.getText();
                String password = new String(jPasswordField.getPassword());
                String password2 = new String(jPasswordField2.getPassword());
                if (!password.equals(password2)) {
                    JOptionPane.showMessageDialog(jFrame, "Two passwords are different!Please input again!");
                    jPasswordField.setText("");
                    jPasswordField2.setText("");
                } else {
                    customer = new Customer();
                    customer.setName(name);
                    customer.setAccountNumber(account);
                    customer.setPassword(password);
                    customer.setSex("man");
                    customer.setEmail("justSimple@126.com");
                    userService = new UserService();
                    boolean judge = userService.Register(customer);
                    if (judge) {
                        jFrame.dispose();
                        LoginPage login = new LoginPage();
                        JOptionPane.showMessageDialog(login.getjFrame(), "Succeed to Register!");
                    } else {
                        JOptionPane.showMessageDialog(jFrame, "Account already exists! Please use another account!");
                        jTextField2.setText("");
                    }
                }
            }
        });
    }

    //定义按下回车实现的功能
    private void keyPressed() {
        jPasswordField2.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                int target = e.getKeyCode();
                if(target == KeyEvent.VK_ENTER) {
                    String name = jTextField.getText();
                    String account = jTextField2.getText();
                    String password = new String(jPasswordField.getPassword());
                    String password2 = new String(jPasswordField2.getPassword());
                    if(!password.equals(password2)) {
                        JOptionPane.showMessageDialog(jFrame,"Two passwords are different!Please input again!");
                        jPasswordField.setText("");
                        jPasswordField2.setText("");
                    }
                    else{
                        customer = new Customer();
                        customer.setName(name);
                        customer.setAccountNumber(account);
                        customer.setPassword(password);
                        customer.setSex("man");
                        customer.setEmail("ancientmoon@126.com");
                        userService = new UserService();
                        boolean judge = userService.Register(customer);
                        if(judge) {
                            jFrame.dispose();
                            LoginPage login = new LoginPage();
                            JOptionPane.showMessageDialog(login.getjFrame(),"Succeed to Register!");
                        }else {
                            JOptionPane.showMessageDialog(jFrame,"Account already exists! Please use another account!");
                            jTextField2.setText("");
                        }
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }
}

//商品信息页面
class MainPage{
    private Customer customer;
    private JFrame jFrame;
    private JLabel jLabel;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel[] jLabels = new JLabel[12];
    private JButton jButton;
    private JButton jButton2;
    private ShoppingCart shoppingCart;
    private Goods goods;
    private int k = 0;
    private String[] urls = {"/icon/dog.png","/icon/cat.png","/icon/turtle.png",
            "/icon/parrot.png","/icon/hamster.png","/icon/squirrel.png",
            "/icon/rabbit.png","/icon/snake.png","/icon/lizard.png",
            "/icon/fish.png","/icon/myna.png","/icon/canary.png",};

    public MainPage(Customer customer){
        this.customer = customer;
        shoppingCart = customer.getCart();
        setjFrame();
        setjLabel();
        setjLabel2();
        setjLabel3();
        setjButton();
        setjButton2();
        setjLabels();
    }

    //构造页面窗口
    private void setjFrame() {
        jFrame = new JFrame("Pet Shop");
        jFrame.setLayout(null);
        jFrame.setBounds(400, 100, 450, 500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置标签1
    private void setjLabel() {
        jLabel = new JLabel("Welcome!  "+customer.getName());
        jLabel.setBounds(30,10,100,20);
        jFrame.add(jLabel);
    }

    //设置标签2
    private void setjLabel2() {
        jLabel2 = new JLabel("Here are pet-goods in our shop.");
        jLabel2.setBounds(30,40,200,20);
        jFrame.add(jLabel2);
    }

    //设置退出按钮
    private void setjButton() {
        jButton = new JButton("Logout");
        jButton.setBounds(330,10,100,20);
        jFrame.add(jButton);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                new LoginPage();
            }
        });
    }

    //设置购物车按钮
    private void setjButton2() {
        jButton2 = new JButton("ShopCart");
        jButton2.setBounds(330,40,100,20);
        jFrame.add(jButton2);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                new ShopCartPage(customer);
            }
        });
    }

    //设置分割线
    private void setjLabel3() {
        String line = new String();
        for(int i=0;i<450;i++) {
            line += "-";
        }
        jLabel3 = new JLabel(line);
        jLabel3.setBounds(0, 80, 450, 5);
        jFrame.add(jLabel3);
    }

    //设置宠物图片
    private void setjLabels() {
        for(int i=0;i<12;i++) {
            URL url = MainPage.class.getResource(urls[i]);
            Icon icon = new ImageIcon(url);
            jLabels[i] = new JLabel(icon);
            if(i/3==0) {
                jLabels[i].setBounds(30+110*i,90,90,90);
            }
            else if(i/3==1) {
                jLabels[i].setBounds(30+110*(i-3),180,90,90);
            }
            else if(i/3==2){
                jLabels[i].setBounds(30+110*(i-6),280,90,90);
            }
            else {
                jLabels[i].setBounds(30+110*(i-9),280,80,80);
            }
            jFrame.add(jLabels[i]);
        }
        jLabels[0].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer, 1);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[1].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer, 2);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[2].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,3);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[3].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,4);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[4].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,5);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[5].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,6);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[6].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,7);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[7].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,8);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[8].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,9);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[9].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,10);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[10].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer,11);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        jLabels[11].addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jFrame.dispose();
                new PetPage(customer, 12);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    public JFrame getjFrame() {
        return jFrame;
    }
}

//宠物详细信息页面
class PetPage{
    private Customer customer;
    private ShoppingCart shoppingCart;
    private int counts;
    private int id;
    private GoodsMySQL_TABLE goodsMySQL_tabl;
    private Goods goods;
    private JFrame jFrame;
    private JLabel jLabel;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    private JTextField jTextField;
    private JButton jButton;
    private JButton jButton2;
    private JButton jButton3;
    private String[] urls = {"/icon/dog.png","/icon/cat.png","/icon/turtle.png",
            "/icon/parrot.png","/icon/hamster.png","/icon/squirrel.png",
            "/icon/rabbit.png","/icon/snake.png","/icon/lizard.png",
            "/icon/fish.png","/icon/myna.png","/icon/canary.png",};


    public PetPage(Customer customer,int id) {
        this.customer = customer;
        shoppingCart = customer.getCart();
        this.id = id;
        goodsMySQL_tabl = new GoodsMySQL_TABLE();
        goods = goodsMySQL_tabl.getGoods(id);
        setjFrame();
        setjLabel();
        setjLabel2();
        setjLabel3();
        setjLabel4();
        setjLabel5();
        setjLabel6();
        setjLabel7();
        setjLabel8();
        setjLabel9();
        setjTextField();
        setjButton();
        setjButton2();
        setjButton3();
        keyPressed();
    }

    private void setjFrame() {
        jFrame = new JFrame("Pet");
        jFrame.setLayout(null);
        jFrame.setBounds(400,100,450,500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置返回按钮
    private void setjButton2() {
        jButton2 = new JButton("<——Back");
        jButton2.setBounds(0,0,100,20);
        jFrame.add(jButton2);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customer.setCart(shoppingCart);
                jFrame.dispose();
                new MainPage(customer);
            }
        });
    }

    //设置购物车按钮
    private void setjButton3() {
        jButton3 = new JButton("ShopCart");
        jButton3.setBounds(350,0,100,20);
        jFrame.add(jButton3);
        jButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customer.setCart(shoppingCart);
                jFrame.dispose();
                new ShopCartPage(customer);
            }
        });
    }
    //设置标签1
    private void setjLabel() {
        URL url = PetPage.class.getResource(urls[id-1]);
        Icon icon = new ImageIcon(url);
        jLabel = new JLabel(icon);
        jLabel.setBounds(170,60,100,100);
        jFrame.add(jLabel);
    }

    //设置标签2
    private void setjLabel2() {
        jLabel2 = new JLabel("Name:   "+goods.getName());
        jLabel2.setBounds(30,170,200,20);
        jFrame.add(jLabel2);
    }

    //设置标签3
    private void setjLabel3() {
        jLabel3 = new JLabel("Eat:   "+goods.getEat());
        jLabel3.setBounds(30,200,200,20);
        jFrame.add(jLabel3);
    }

    //设置标签4
    private void setjLabel4() {
        jLabel4 = new JLabel("Drink:   "+goods.getDrink());
        jLabel4.setBounds(30,230,200,20);
        jFrame.add(jLabel4);
    }

    //设置标签5
    private void setjLabel5() {
        jLabel5 = new JLabel("Live:   "+goods.getLive());
        jLabel5.setBounds(30,260,200,20);
        jFrame.add(jLabel5);
    }

    //设置标签6
    private void setjLabel6() {
        jLabel6 = new JLabel("Hobby:   "+goods.getHobby());
        jLabel6.setBounds(30,290,200,20);
        jFrame.add(jLabel6);
    }

    //设置标签7
    private void setjLabel7() {
        jLabel7 = new JLabel("Price:   "+goods.getPrice()+"¥");
        jLabel7.setBounds(30,320,200,20);
        jFrame.add(jLabel7);
    }

    //设置标签8
    private void setjLabel8() {
        jLabel8 = new JLabel("Inventory:   "+goods.getInventory());
        jLabel8.setBounds(30,350,200,20);
        jFrame.add(jLabel8);
    }

    //设置标签9
    private void setjLabel9() {
        jLabel9 = new JLabel("Want to buy:   ");
        jLabel9.setBounds(30,380,100,20);
        jFrame.add(jLabel9);
    }

    //设置购买输入框
    private void setjTextField() {
        jTextField = new JTextField();
        jTextField.setBounds(120,380,100,20);
        jFrame.add(jTextField);
    }

    //设置添加至购物车按钮
    private void setjButton() {
        jButton = new JButton("Add to my ShopCart");
        jButton.setBounds(230,380,200,20);
        jFrame.add(jButton);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                counts = Integer.parseInt(jTextField.getText());
                int inventory = goods.getInventory();
                if(inventory<counts) {
                    JOptionPane.showMessageDialog(jFrame,"The inventory is not sufficient.Please input less.");
                    jTextField.setText("");
                }
                else {
                    shoppingCart.add(id,counts);
                    JOptionPane.showMessageDialog(jFrame,"Succeed to add to your cart!");
                    jTextField.setText("");
                }
            }
        });
    }

    //定义按下回车键实现的购买功能
    private void keyPressed() {
        jTextField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                int target = e.getKeyCode();
                if(target==KeyEvent.VK_ENTER) {
                    counts = Integer.parseInt(jTextField.getText());
                    int inventory = goods.getInventory();
                    if(inventory<counts) {
                        JOptionPane.showMessageDialog(jFrame,"The inventory is not sufficient.Please input less.");
                        jTextField.setText("");
                    }
                    else {
                        shoppingCart.add(id,counts);
                        JOptionPane.showMessageDialog(jFrame,"Succeed to add to your cart!");
                        jTextField.setText("");
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }
}

//购物车页面
class ShopCartPage{
    private Customer customer;
    private ShoppingCart shoppingCart;
    private JFrame jFrame;
    private JButton jButton;
    private JLabel jLabel;
    private JLabel[] jLabels;
    private JLabel jLabel2;
    private JButton jButton2;
    private float prices = 0;
    private int keys = 0;
    private GoodsMySQL_TABLE goodsMySQL_table;
    private Goods goods;
    private Set set;
    private Connection connection;
    private Statement statement;
    private int newInventory;


    public ShopCartPage(Customer customer) {
        connection = LinkToMySQL.getConnection();
        try{
            statement = connection.createStatement();
        }catch (Exception e){
            e.getMessage();
            e.printStackTrace();
        }
        this.customer = customer;
        shoppingCart = customer.getCart();
        set = shoppingCart.getMap().keySet();
        keys = set.size();
        jLabels = new JLabel[keys];
        goodsMySQL_table = new GoodsMySQL_TABLE();
        setjFrame();
        setjButton();
        setjLabel();
        setGoodsList();
        setjLabel2();
        setjButton2();
    }

    //构造窗口
    private void setjFrame() {
        jFrame = new JFrame("ShopCartPage");
        jFrame.setLayout(null);
        jFrame.setBounds(400,100,450,500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置返回按钮
    private void setjButton() {
        jButton = new JButton("<——Back");
        jButton.setBounds(0,0,100,20);
        jFrame.add(jButton);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customer.setCart(shoppingCart);
                jFrame.dispose();
                new MainPage(customer);
            }
        });
    }

    //设置标签1
    private void setjLabel() {
        jLabel = new JLabel("Here are your shopping list:");
        jLabel.setBounds(30,20,200,20);
        jFrame.add(jLabel);
    }

    //设置选中商品列表
    private void setGoodsList() {
        Iterator iterator = set.iterator();
        for(int i=0;i<keys;i++) {
            if(iterator.hasNext()) {
                int key =(Integer)iterator.next();
                goods = goodsMySQL_table.getGoods(key);
                prices += goods.getPrice()*shoppingCart.getMap().get(key);
                jLabels[i] = new JLabel(goods.getName()+":   "+shoppingCart.getMap().get(key));
                jLabels[i].setBounds(30, 20 + 30 * (i + 1), 100, 20);
                jFrame.add(jLabels[i]);
            }
        }
    }

    //设置标签显示价格总数
    private void setjLabel2() {
        jLabel2 = new JLabel("Sum of prices is:   "+prices+"¥");
        jLabel2.setBounds(30,400,200,20);
        jFrame.add(jLabel2);
    }

    //设置购买按钮
    private void setjButton2() {
        jButton2 = new JButton("Pay");
        jButton2.setBounds(250,400,100,20);
        jFrame.add(jButton2);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Iterator iterator = set.iterator();
                for(int i=0;i<keys;i++) {
                    if(iterator.hasNext()){
                        int key = (Integer)iterator.next();
                        try {
                            goods = goodsMySQL_table.getGoods(key);
                            statement.executeUpdate("update 2014302580184_goods set inventory="+"'"+(goods.getInventory()-shoppingCart.getMap().get(key))+"'"+"where id="+"'"+key+"'");
                        }catch (Exception k){
                            k.getMessage();
                            k.printStackTrace();
                        }
                    }
                }
                shoppingCart.delete();
                customer.setCart(shoppingCart);
                jFrame.dispose();
                MainPage mainPage = new MainPage(customer);
                JOptionPane.showMessageDialog(mainPage.getjFrame(),"Succeed to buy!");
            }
        });
    }

}
