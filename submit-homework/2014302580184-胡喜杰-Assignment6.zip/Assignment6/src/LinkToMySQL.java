import java.sql.Connection;
import java.sql.DriverManager;

/**
 * 数据库的连接
 */
public class LinkToMySQL {
    private static Connection connection;

    public static Connection getConnection(){
        //加载JDBC驱动程序
        try{
            Class.forName("com.mysql.jdbc.Driver"); //动态加载驱动程序
        }catch(ClassNotFoundException e){
            System.out.println("找不到程序驱动类，加载驱动失败");
            e.printStackTrace();
        }

        //提供JDBC连接的URL
        String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"+
                "user=root&password=123456&useUnicode=true&characterEncoding=GBK";

        //创建数据库连接
        try{
            connection = DriverManager.getConnection(url);
        }catch (Exception e){
            System.out.println("数据库连接失败");
            e.printStackTrace();
        }

        return connection;
    }

}
