import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * 从数据库中获取用户信息
 */
public class Customer_MySQL_TABLE {
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private Customer customer = new Customer();

    public Customer_MySQL_TABLE() {
        this.connection = LinkToMySQL.getConnection();
    }

    public Customer getCustomer(String accountnumber) {
        try{
            statement = connection.createStatement();

            resultSet = statement.executeQuery("select * from 2014302580184_user where accountNumber = "+"'"+accountnumber+"'");
            if(resultSet.next()) {
                customer.setId(resultSet.getInt(1));
                customer.setName(resultSet.getString(2));
                customer.setSex(resultSet.getString(3));
                customer.setAccountNumber(resultSet.getString(4));
                customer.setPassword(resultSet.getString(5));
                customer.setEmail(resultSet.getString(6));
            }
            return customer;
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
